#!/bin/bash
# Start Above Live backend server
cd "$(dirname "$0")/backend"
npm install --omit=dev
node server.js
